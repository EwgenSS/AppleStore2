using System;
using System.Collections.Generic;
using AppleStore.Models;
using AppleStore.Data;
using Microsoft.EntityFrameworkCore;

namespace AppleStore.Services
{
    public class DatabaseInitializer
    {
        private readonly AppleStoreDbContext _context;
        private readonly DatabaseChangeService _changeService;

        public DatabaseInitializer(AppleStoreDbContext context, DatabaseChangeService changeService)
        {
            _context = context;
            _changeService = changeService;
        }

        public void Initialize()
        {
            // Создаем базу данных, если она не существует
            _context.Database.EnsureCreated();

            // Проверяем, есть ли уже данные в базе
            if (_context.Customers.Any())
            {
                return; // База уже инициализирована
            }

            // Добавляем тестовых клиентов
            AddTestCustomers();

            // Добавляем тестовые покупки
            AddTestPurchases();

            Console.WriteLine("База данных успешно инициализирована тестовыми данными.");
        }

        private void AddTestCustomers()
        {
            var customers = new List<Customer>
            {
                new Customer
                {
                    FullName = "Иванов Иван Иванович",
                    Email = "ivanov@example.com",
                    Phone = "+7 (900) 123-45-67",
                    Address = "г. Москва, ул. Ленина, д. 1, кв. 10",
                    RegistrationDate = DateTime.Now.AddDays(-100)
                },
                new Customer
                {
                    FullName = "Петров Петр Петрович",
                    Email = "petrov@example.com",
                    Phone = "+7 (900) 234-56-78",
                    Address = "г. Санкт-Петербург, пр. Невский, д. 5, кв. 15",
                    RegistrationDate = DateTime.Now.AddDays(-90)
                },
                new Customer
                {
                    FullName = "Сидорова Анна Сергеевна",
                    Email = "sidorova@example.com",
                    Phone = "+7 (900) 345-67-89",
                    Address = "г. Екатеринбург, ул. Мира, д. 10, кв. 20",
                    RegistrationDate = DateTime.Now.AddDays(-80)
                },
                new Customer
                {
                    FullName = "Козлов Алексей Дмитриевич",
                    Email = "kozlov@example.com",
                    Phone = "+7 (900) 456-78-90",
                    Address = "г. Новосибирск, ул. Гагарина, д. 15, кв. 25",
                    RegistrationDate = DateTime.Now.AddDays(-70)
                },
                new Customer
                {
                    FullName = "Смирнова Елена Александровна",
                    Email = "smirnova@example.com",
                    Phone = "+7 (900) 567-89-01",
                    Address = "г. Казань, ул. Пушкина, д. 20, кв. 30",
                    RegistrationDate = DateTime.Now.AddDays(-60)
                },
                new Customer
                {
                    FullName = "Новиков Михаил Владимирович",
                    Email = "novikov@example.com",
                    Phone = "+7 (900) 678-90-12",
                    Address = "г. Нижний Новгород, ул. Советская, д. 25, кв. 35",
                    RegistrationDate = DateTime.Now.AddDays(-50)
                },
                new Customer
                {
                    FullName = "Морозова Ольга Игоревна",
                    Email = "morozova@example.com",
                    Phone = "+7 (900) 789-01-23",
                    Address = "г. Челябинск, ул. Ленинградская, д. 30, кв. 40",
                    RegistrationDate = DateTime.Now.AddDays(-40)
                },
                new Customer
                {
                    FullName = "Волков Дмитрий Сергеевич",
                    Email = "volkov@example.com",
                    Phone = "+7 (900) 890-12-34",
                    Address = "г. Самара, ул. Московская, д. 35, кв. 45",
                    RegistrationDate = DateTime.Now.AddDays(-30)
                },
                new Customer
                {
                    FullName = "Кузнецова Мария Андреевна",
                    Email = "kuznetsova@example.com",
                    Phone = "+7 (900) 901-23-45",
                    Address = "г. Ростов-на-Дону, ул. Кирова, д. 40, кв. 50",
                    RegistrationDate = DateTime.Now.AddDays(-20)
                },
                new Customer
                {
                    FullName = "Соколов Артем Николаевич",
                    Email = "sokolov@example.com",
                    Phone = "+7 (900) 012-34-56",
                    Address = "г. Уфа, ул. Чехова, д. 45, кв. 55",
                    RegistrationDate = DateTime.Now.AddDays(-10)
                }
            };

            _context.Customers.AddRange(customers);
            _context.SaveChanges();

            // Логируем добавление клиентов
            foreach (var customer in customers)
            {
                _changeService.LogChange("Customers", customer.CustomerId, "Add", 1, 
                    $"Добавлен тестовый клиент: {customer.FullName}");
            }
        }

        private void AddTestPurchases()
        {
            // Получаем всех клиентов
            var customers = _context.Customers.ToList();
            
            // Список продуктов Apple для тестовых данных
            var products = new List<(int Id, string Name, decimal Price)>
            {
                (1, "iPhone 15 Pro", 999.99m),
                (2, "iPhone 15", 799.99m),
                (3, "MacBook Pro 16\"", 2499.99m),
                (4, "MacBook Air 13\"", 1299.99m),
                (5, "iPad Pro 12.9\"", 1099.99m),
                (6, "iPad Air", 599.99m),
                (7, "Apple Watch Series 9", 399.99m),
                (8, "Apple Watch SE", 249.99m),
                (9, "AirPods Pro", 249.99m),
                (10, "AirPods", 129.99m)
            };

            // Статусы покупок
            var statuses = new[] { "Оплачено", "Доставлено", "В обработке", "Отменено" };

            // Создаем случайные покупки
            var random = new Random();
            var purchases = new List<Purchase>();

            foreach (var customer in customers)
            {
                // Для каждого клиента создаем от 1 до 3 покупок
                int purchaseCount = random.Next(1, 4);
                
                for (int i = 0; i < purchaseCount; i++)
                {
                    // Выбираем случайный продукт
                    var product = products[random.Next(products.Count)];
                    
                    // Создаем покупку
                    var purchase = new Purchase
                    {
                        CustomerId = customer.CustomerId,
                        ProductId = product.Id,
                        PurchaseDate = DateTime.Now.AddDays(-random.Next(1, 30)),
                        Quantity = random.Next(1, 4),
                        Price = product.Price,
                        Status = statuses[random.Next(statuses.Length)],
                        Customer = customer
                    };
                    
                    // Рассчитываем общую сумму
                    purchase.TotalAmount = purchase.Price * purchase.Quantity;
                    
                    purchases.Add(purchase);
                }
            }

            _context.Purchases.AddRange(purchases);
            _context.SaveChanges();

            // Логируем добавление покупок
            foreach (var purchase in purchases)
            {
                var productName = products.FirstOrDefault(p => p.Id == purchase.ProductId).Name;
                _changeService.LogChange("Purchases", purchase.PurchaseId, "Add", 1, 
                    $"Добавлена тестовая покупка: Клиент {purchase.Customer.FullName}, Продукт {productName}, Сумма {purchase.TotalAmount:C}");
            }
        }
    }
}
