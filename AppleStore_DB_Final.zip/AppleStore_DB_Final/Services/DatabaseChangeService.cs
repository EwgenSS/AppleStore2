using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using AppleStore.Models;
using AppleStore.Data;

namespace AppleStore.Services
{
    public class DatabaseChangeService
    {
        private readonly AppleStoreDbContext _context;

        public DatabaseChangeService(AppleStoreDbContext context)
        {
            _context = context;
        }

        // Логирование изменения в базе данных
        public void LogChange(string tableName, int recordId, string changeType, int userId, string description)
        {
            var change = new DatabaseChange
            {
                TableName = tableName,
                RecordId = recordId,
                ChangeType = changeType,
                ChangeDate = DateTime.Now,
                UserId = userId,
                Description = description
            };

            _context.DatabaseChanges.Add(change);
            _context.SaveChanges();
        }

        // Получить все изменения
        public List<DatabaseChange> GetAllChanges()
        {
            return _context.DatabaseChanges
                .OrderByDescending(c => c.ChangeDate)
                .ToList();
        }

        // Получить изменения по таблице
        public List<DatabaseChange> GetChangesByTable(string tableName)
        {
            return _context.DatabaseChanges
                .Where(c => c.TableName == tableName)
                .OrderByDescending(c => c.ChangeDate)
                .ToList();
        }

        // Получить изменения по типу
        public List<DatabaseChange> GetChangesByType(string changeType)
        {
            return _context.DatabaseChanges
                .Where(c => c.ChangeType == changeType)
                .OrderByDescending(c => c.ChangeDate)
                .ToList();
        }

        // Получить изменения по дате
        public List<DatabaseChange> GetChangesByDate(DateTime date)
        {
            return _context.DatabaseChanges
                .Where(c => c.ChangeDate.Date == date.Date)
                .OrderByDescending(c => c.ChangeDate)
                .ToList();
        }

        // Получить изменения по пользователю
        public List<DatabaseChange> GetChangesByUser(int userId)
        {
            return _context.DatabaseChanges
                .Where(c => c.UserId == userId)
                .OrderByDescending(c => c.ChangeDate)
                .ToList();
        }

        // Очистить журнал изменений старше определенной даты
        public int ClearOldChanges(DateTime olderThan)
        {
            var oldChanges = _context.DatabaseChanges
                .Where(c => c.ChangeDate < olderThan)
                .ToList();

            if (oldChanges.Any())
            {
                _context.DatabaseChanges.RemoveRange(oldChanges);
                _context.SaveChanges();
            }

            return oldChanges.Count;
        }
    }
}
