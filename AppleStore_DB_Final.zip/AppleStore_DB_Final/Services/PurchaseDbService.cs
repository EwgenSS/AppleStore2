using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using AppleStore.Models;
using AppleStore.Data;

namespace AppleStore.Services
{
    public class PurchaseDbService
    {
        private readonly AppleStoreDbContext _context;
        private readonly DatabaseChangeService _changeService;

        public PurchaseDbService(AppleStoreDbContext context, DatabaseChangeService changeService)
        {
            _context = context;
            _changeService = changeService;
        }

        // Получить все покупки
        public List<Purchase> GetAllPurchases()
        {
            return _context.Purchases
                .Include(p => p.Customer)
                .ToList();
        }

        // Получить покупку по ID
        public Purchase GetPurchaseById(int id)
        {
            return _context.Purchases
                .Include(p => p.Customer)
                .FirstOrDefault(p => p.PurchaseId == id);
        }

        // Получить покупки клиента
        public List<Purchase> GetPurchasesByCustomerId(int customerId)
        {
            return _context.Purchases
                .Include(p => p.Customer)
                .Where(p => p.CustomerId == customerId)
                .ToList();
        }

        // Добавить новую покупку
        public Purchase AddPurchase(Purchase purchase)
        {
            purchase.PurchaseDate = DateTime.Now;
            purchase.TotalAmount = purchase.Price * purchase.Quantity;
            
            _context.Purchases.Add(purchase);
            _context.SaveChanges();

            // Логирование изменения
            _changeService.LogChange("Purchases", purchase.PurchaseId, "Add", 1, 
                $"Добавлена новая покупка: Клиент ID {purchase.CustomerId}, Продукт ID {purchase.ProductId}, Сумма {purchase.TotalAmount:C}");

            return purchase;
        }

        // Обновить информацию о покупке
        public bool UpdatePurchase(Purchase purchase)
        {
            try
            {
                var existingPurchase = _context.Purchases.Find(purchase.PurchaseId);
                if (existingPurchase == null)
                    return false;

                // Пересчитываем общую сумму
                purchase.TotalAmount = purchase.Price * purchase.Quantity;
                
                _context.Entry(existingPurchase).CurrentValues.SetValues(purchase);
                _context.SaveChanges();

                // Логирование изменения
                _changeService.LogChange("Purchases", purchase.PurchaseId, "Update", 1, 
                    $"Обновлена информация о покупке: ID {purchase.PurchaseId}, Сумма {purchase.TotalAmount:C}");

                return true;
            }
            catch
            {
                return false;
            }
        }

        // Удалить покупку
        public bool DeletePurchase(int id)
        {
            try
            {
                var purchase = _context.Purchases.Find(id);
                if (purchase == null)
                    return false;

                _context.Purchases.Remove(purchase);
                _context.SaveChanges();

                // Логирование изменения
                _changeService.LogChange("Purchases", id, "Delete", 1, 
                    $"Удалена покупка: ID {id}");

                return true;
            }
            catch
            {
                return false;
            }
        }

        // Поиск покупок по дате
        public List<Purchase> SearchPurchasesByDate(DateTime date)
        {
            return _context.Purchases
                .Include(p => p.Customer)
                .Where(p => p.PurchaseDate.Date == date.Date)
                .ToList();
        }

        // Получить статистику по покупкам
        public Dictionary<string, decimal> GetPurchaseStatistics()
        {
            var statistics = new Dictionary<string, decimal>();
            
            statistics["TotalAmount"] = _context.Purchases.Sum(p => p.TotalAmount);
            statistics["AverageAmount"] = _context.Purchases.Any() ? 
                _context.Purchases.Average(p => p.TotalAmount) : 0;
            statistics["MaxAmount"] = _context.Purchases.Any() ? 
                _context.Purchases.Max(p => p.TotalAmount) : 0;
            
            return statistics;
        }
    }
}
