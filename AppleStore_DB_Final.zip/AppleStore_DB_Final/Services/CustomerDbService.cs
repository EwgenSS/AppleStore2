using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using AppleStore.Models;
using AppleStore.Data;

namespace AppleStore.Services
{
    public class CustomerDbService
    {
        private readonly AppleStoreDbContext _context;
        private readonly DatabaseChangeService _changeService;

        public CustomerDbService(AppleStoreDbContext context, DatabaseChangeService changeService)
        {
            _context = context;
            _changeService = changeService;
        }

        // Получить всех клиентов
        public List<Customer> GetAllCustomers()
        {
            return _context.Customers.ToList();
        }

        // Получить клиента по ID
        public Customer GetCustomerById(int id)
        {
            return _context.Customers.Find(id);
        }

        // Добавить нового клиента
        public Customer AddCustomer(Customer customer)
        {
            customer.RegistrationDate = DateTime.Now;
            _context.Customers.Add(customer);
            _context.SaveChanges();

            // Логирование изменения
            _changeService.LogChange("Customers", customer.CustomerId, "Add", 1, 
                $"Добавлен новый клиент: {customer.FullName}");

            return customer;
        }

        // Обновить информацию о клиенте
        public bool UpdateCustomer(Customer customer)
        {
            try
            {
                var existingCustomer = _context.Customers.Find(customer.CustomerId);
                if (existingCustomer == null)
                    return false;

                _context.Entry(existingCustomer).CurrentValues.SetValues(customer);
                _context.SaveChanges();

                // Логирование изменения
                _changeService.LogChange("Customers", customer.CustomerId, "Update", 1, 
                    $"Обновлена информация о клиенте: {customer.FullName}");

                return true;
            }
            catch
            {
                return false;
            }
        }

        // Удалить клиента
        public bool DeleteCustomer(int id)
        {
            try
            {
                var customer = _context.Customers.Find(id);
                if (customer == null)
                    return false;

                string customerName = customer.FullName;
                _context.Customers.Remove(customer);
                _context.SaveChanges();

                // Логирование изменения
                _changeService.LogChange("Customers", id, "Delete", 1, 
                    $"Удален клиент: {customerName}");

                return true;
            }
            catch
            {
                return false;
            }
        }

        // Поиск клиентов по имени
        public List<Customer> SearchCustomersByName(string name)
        {
            return _context.Customers
                .Where(c => c.FullName.Contains(name))
                .ToList();
        }
    }
}
