using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AppleStore.Models
{
    public class Customer
    {
        [Key]
        public int CustomerId { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string FullName { get; set; }
        
        [MaxLength(100)]
        public string Email { get; set; }
        
        [MaxLength(20)]
        public string Phone { get; set; }
        
        [MaxLength(200)]
        public string Address { get; set; }
        
        public DateTime RegistrationDate { get; set; }
        
        // Навигационное свойство для связи с покупками
        public virtual ICollection<Purchase> Purchases { get; set; } = new List<Purchase>();
    }
}
