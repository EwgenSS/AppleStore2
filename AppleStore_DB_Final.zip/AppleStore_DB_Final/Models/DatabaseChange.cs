using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AppleStore.Models
{
    public class DatabaseChange
    {
        [Key]
        public int ChangeId { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string TableName { get; set; }
        
        public int RecordId { get; set; }
        
        [Required]
        [MaxLength(20)]
        public string ChangeType { get; set; }
        
        public DateTime ChangeDate { get; set; }
        
        public int UserId { get; set; }
        
        [MaxLength(255)]
        public string Description { get; set; }
    }
}
