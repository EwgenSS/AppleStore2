using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AppleStore.Models
{
    public class Purchase
    {
        [Key]
        public int PurchaseId { get; set; }
        
        public int CustomerId { get; set; }
        
        public int ProductId { get; set; }
        
        public DateTime PurchaseDate { get; set; }
        
        public int Quantity { get; set; }
        
        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }
        
        [Column(TypeName = "decimal(18, 2)")]
        public decimal TotalAmount { get; set; }
        
        [MaxLength(50)]
        public string Status { get; set; }
        
        // Навигационные свойства
        [ForeignKey("CustomerId")]
        public virtual Customer Customer { get; set; }
        
        // Можно добавить навигационное свойство к Product, если нужно
        // [ForeignKey("ProductId")]
        // public virtual Product Product { get; set; }
    }
}
