using System;
using System.Collections.Generic;
using System.Linq;
using AppleStore.Models;
using AppleStore.Services;
using AppleStore.Data;
using Microsoft.EntityFrameworkCore;

namespace AppleStore.UI
{
    public class ConsoleUI
    {
        private readonly CategoryService _categoryService;
        private readonly ProductService _productService;
        private readonly ProductDetailsService _productDetailsService;
        private readonly CustomerService _customerService;
        private readonly EmployeeService _employeeService;
        private readonly OrderService _orderService;
        private readonly OrderItemService _orderItemService;
        private readonly DatabaseUI _databaseUI;

        public ConsoleUI(
            CategoryService categoryService,
            ProductService productService,
            ProductDetailsService productDetailsService,
            CustomerService customerService,
            EmployeeService employeeService,
            OrderService orderService,
            OrderItemService orderItemService,
            DatabaseUI databaseUI)
        {
            _categoryService = categoryService;
            _productService = productService;
            _productDetailsService = productDetailsService;
            _customerService = customerService;
            _employeeService = employeeService;
            _orderService = orderService;
            _orderItemService = orderItemService;
            _databaseUI = databaseUI;
        }

        public void Start()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Apple Store ===");
                Console.WriteLine("1. Управление категориями");
                Console.WriteLine("2. Управление продуктами");
                Console.WriteLine("3. Управление клиентами");
                Console.WriteLine("4. Управление сотрудниками");
                Console.WriteLine("5. Управление заказами");
                Console.WriteLine("6. Просмотр каталога продуктов");
                Console.WriteLine("7. Управление базой данных");
                Console.WriteLine("0. Выход");
                Console.Write("\nВыберите действие: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            ShowCategoryMenu();
                            break;
                        case 2:
                            ShowProductMenu();
                            break;
                        case 3:
                            ShowCustomerMenu();
                            break;
                        case 4:
                            ShowEmployeeMenu();
                            break;
                        case 5:
                            ShowOrderMenu();
                            break;
                        case 6:
                            ShowProductCatalog();
                            break;
                        case 7:
                            _databaseUI.ShowDatabaseMenu();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Нажмите любую клавишу для продолжения...");
                            Console.ReadKey();
                            break;
                    }
                }
            }
        }

        // Остальной код ConsoleUI остается без изменений...
        
        // Существующие методы для работы с категориями, продуктами, клиентами, сотрудниками и заказами
    }
}
