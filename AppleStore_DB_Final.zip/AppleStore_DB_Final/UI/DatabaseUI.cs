using System;
using System.Collections.Generic;
using System.Linq;
using AppleStore.Models;
using AppleStore.Services;
using AppleStore.Data;
using Microsoft.EntityFrameworkCore;

namespace AppleStore.UI
{
    public class DatabaseUI
    {
        private readonly CustomerDbService _customerService;
        private readonly PurchaseDbService _purchaseService;
        private readonly DatabaseChangeService _changeService;

        public DatabaseUI(CustomerDbService customerService, PurchaseDbService purchaseService, DatabaseChangeService changeService)
        {
            _customerService = customerService;
            _purchaseService = purchaseService;
            _changeService = changeService;
        }

        public void ShowDatabaseMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Управление базой данных ===");
                Console.WriteLine("1. Управление клиентами");
                Console.WriteLine("2. Управление покупками");
                Console.WriteLine("3. Просмотр журнала изменений");
                Console.WriteLine("0. Вернуться в главное меню");
                Console.Write("\nВыберите действие: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            ShowCustomerMenu();
                            break;
                        case 2:
                            ShowPurchaseMenu();
                            break;
                        case 3:
                            ShowDatabaseChangesMenu();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Нажмите любую клавишу для продолжения...");
                            Console.ReadKey();
                            break;
                    }
                }
            }
        }

        private void ShowCustomerMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Управление клиентами ===");
                Console.WriteLine("1. Просмотреть всех клиентов");
                Console.WriteLine("2. Найти клиента по ID");
                Console.WriteLine("3. Поиск клиентов по имени");
                Console.WriteLine("4. Добавить нового клиента");
                Console.WriteLine("5. Редактировать клиента");
                Console.WriteLine("6. Удалить клиента");
                Console.WriteLine("0. Вернуться в меню базы данных");
                Console.Write("\nВыберите действие: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            DisplayAllCustomers();
                            break;
                        case 2:
                            FindCustomerById();
                            break;
                        case 3:
                            SearchCustomersByName();
                            break;
                        case 4:
                            AddNewCustomer();
                            break;
                        case 5:
                            EditCustomer();
                            break;
                        case 6:
                            DeleteCustomer();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Нажмите любую клавишу для продолжения...");
                            Console.ReadKey();
                            break;
                    }
                }
            }
        }

        private void ShowPurchaseMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Управление покупками ===");
                Console.WriteLine("1. Просмотреть все покупки");
                Console.WriteLine("2. Найти покупку по ID");
                Console.WriteLine("3. Просмотреть покупки клиента");
                Console.WriteLine("4. Поиск покупок по дате");
                Console.WriteLine("5. Добавить новую покупку");
                Console.WriteLine("6. Редактировать покупку");
                Console.WriteLine("7. Удалить покупку");
                Console.WriteLine("8. Статистика по покупкам");
                Console.WriteLine("0. Вернуться в меню базы данных");
                Console.Write("\nВыберите действие: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            DisplayAllPurchases();
                            break;
                        case 2:
                            FindPurchaseById();
                            break;
                        case 3:
                            DisplayCustomerPurchases();
                            break;
                        case 4:
                            SearchPurchasesByDate();
                            break;
                        case 5:
                            AddNewPurchase();
                            break;
                        case 6:
                            EditPurchase();
                            break;
                        case 7:
                            DeletePurchase();
                            break;
                        case 8:
                            ShowPurchaseStatistics();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Нажмите любую клавишу для продолжения...");
                            Console.ReadKey();
                            break;
                    }
                }
            }
        }

        private void ShowDatabaseChangesMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Журнал изменений базы данных ===");
                Console.WriteLine("1. Просмотреть все изменения");
                Console.WriteLine("2. Просмотреть изменения по таблице");
                Console.WriteLine("3. Просмотреть изменения по типу");
                Console.WriteLine("4. Просмотреть изменения по дате");
                Console.WriteLine("5. Очистить старые записи");
                Console.WriteLine("0. Вернуться в меню базы данных");
                Console.Write("\nВыберите действие: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            DisplayAllChanges();
                            break;
                        case 2:
                            DisplayChangesByTable();
                            break;
                        case 3:
                            DisplayChangesByType();
                            break;
                        case 4:
                            DisplayChangesByDate();
                            break;
                        case 5:
                            ClearOldChanges();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Нажмите любую клавишу для продолжения...");
                            Console.ReadKey();
                            break;
                    }
                }
            }
        }

        #region Customer Methods

        private void DisplayAllCustomers()
        {
            Console.Clear();
            Console.WriteLine("=== Список всех клиентов ===\n");

            var customers = _customerService.GetAllCustomers();
            if (customers.Count == 0)
            {
                Console.WriteLine("Клиенты не найдены.");
            }
            else
            {
                foreach (var customer in customers)
                {
                    Console.WriteLine($"ID: {customer.CustomerId}, Имя: {customer.FullName}, Email: {customer.Email}, Телефон: {customer.Phone}");
                }
                Console.WriteLine($"\nВсего клиентов: {customers.Count}");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void FindCustomerById()
        {
            Console.Clear();
            Console.WriteLine("=== Поиск клиента по ID ===\n");

            Console.Write("Введите ID клиента: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var customer = _customerService.GetCustomerById(id);
                if (customer != null)
                {
                    Console.WriteLine("\nИнформация о клиенте:");
                    Console.WriteLine($"ID: {customer.CustomerId}");
                    Console.WriteLine($"Имя: {customer.FullName}");
                    Console.WriteLine($"Email: {customer.Email}");
                    Console.WriteLine($"Телефон: {customer.Phone}");
                    Console.WriteLine($"Адрес: {customer.Address}");
                    Console.WriteLine($"Дата регистрации: {customer.RegistrationDate}");
                }
                else
                {
                    Console.WriteLine($"Клиент с ID {id} не найден.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void SearchCustomersByName()
        {
            Console.Clear();
            Console.WriteLine("=== Поиск клиентов по имени ===\n");

            Console.Write("Введите имя или часть имени: ");
            string name = Console.ReadLine();

            var customers = _customerService.SearchCustomersByName(name);
            if (customers.Count == 0)
            {
                Console.WriteLine($"Клиенты с именем, содержащим '{name}', не найдены.");
            }
            else
            {
                Console.WriteLine("\nНайденные клиенты:");
                foreach (var customer in customers)
                {
                    Console.WriteLine($"ID: {customer.CustomerId}, Имя: {customer.FullName}, Email: {customer.Email}, Телефон: {customer.Phone}");
                }
                Console.WriteLine($"\nВсего найдено: {customers.Count}");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void AddNewCustomer()
        {
            Console.Clear();
            Console.WriteLine("=== Добавление нового клиента ===\n");

            Console.Write("Введите полное имя: ");
            string fullName = Console.ReadLine();

            Console.Write("Введите email: ");
            string email = Console.ReadLine();

            Console.Write("Введите телефон: ");
            string phone = Console.ReadLine();

            Console.Write("Введите адрес: ");
            string address = Console.ReadLine();

            var customer = new Customer
            {
                FullName = fullName,
                Email = email,
                Phone = phone,
                Address = address
            };

            var addedCustomer = _customerService.AddCustomer(customer);
            Console.WriteLine($"\nКлиент успешно добавлен с ID: {addedCustomer.CustomerId}");

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void EditCustomer()
        {
            Console.Clear();
            Console.WriteLine("=== Редактирование клиента ===\n");

            Console.Write("Введите ID клиента для редактирования: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var customer = _customerService.GetCustomerById(id);
                if (customer != null)
                {
                    Console.WriteLine($"Редактирование клиента: {customer.FullName}\n");

                    Console.Write($"Полное имя [{customer.FullName}]: ");
                    string fullName = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(fullName))
                        customer.FullName = fullName;

                    Console.Write($"Email [{customer.Email}]: ");
                    string email = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(email))
                        customer.Email = email;

                    Console.Write($"Телефон [{customer.Phone}]: ");
                    string phone = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(phone))
                        customer.Phone = phone;

                    Console.Write($"Адрес [{customer.Address}]: ");
                    string address = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(address))
                        customer.Address = address;

                    bool success = _customerService.UpdateCustomer(customer);
                    if (success)
                    {
                        Console.WriteLine("\nИнформация о клиенте успешно обновлена.");
                    }
                    else
                    {
                        Console.WriteLine("\nПроизошла ошибка при обновлении информации о клиенте.");
                    }
                }
                else
                {
                    Console.WriteLine($"Клиент с ID {id} не найден.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void DeleteCustomer()
        {
            Console.Clear();
            Console.WriteLine("=== Удаление клиента ===\n");

            Console.Write("Введите ID клиента для удаления: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var customer = _customerService.GetCustomerById(id);
                if (customer != null)
                {
                    Console.WriteLine($"Вы уверены, что хотите удалить клиента: {customer.FullName}? (д/н)");
                    string confirmation = Console.ReadLine().ToLower();

                    if (confirmation == "д" || confirmation == "да" || confirmation == "y" || confirmation == "yes")
                    {
                        bool success = _customerService.DeleteCustomer(id);
                        if (success)
                        {
                            Console.WriteLine("Клиент успешно удален.");
                        }
                        else
                        {
                            Console.WriteLine("Произошла ошибка при удалении клиента.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Удаление отменено.");
                    }
                }
                else
                {
                    Console.WriteLine($"Клиент с ID {id} не найден.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        #endregion

        #region Purchase Methods

        private void DisplayAllPurchases()
        {
            Console.Clear();
            Console.WriteLine("=== Список всех покупок ===\n");

            var purchases = _purchaseService.GetAllPurchases();
            if (purchases.Count == 0)
            {
                Console.WriteLine("Покупки не найдены.");
            }
            else
            {
                foreach (var purchase in purchases)
                {
                    Console.WriteLine($"ID: {purchase.PurchaseId}, Клиент: {purchase.Customer?.FullName}, Продукт ID: {purchase.ProductId}, Дата: {purchase.PurchaseDate.ToShortDateString()}, Сумма: {purchase.TotalAmount:C}");
                }
                Console.WriteLine($"\nВсего покупок: {purchases.Count}");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void FindPurchaseById()
        {
            Console.Clear();
            Console.WriteLine("=== Поиск покупки по ID ===\n");

            Console.Write("Введите ID покупки: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var purchase = _purchaseService.GetPurchaseById(id);
                if (purchase != null)
                {
                    Console.WriteLine("\nИнформация о покупке:");
                    Console.WriteLine($"ID: {purchase.PurchaseId}");
                    Console.WriteLine($"Клиент: {purchase.Customer?.FullName}");
                    Console.WriteLine($"Продукт ID: {purchase.ProductId}");
                    Console.WriteLine($"Дата: {purchase.PurchaseDate}");
                    Console.WriteLine($"Количество: {purchase.Quantity}");
                    Console.WriteLine($"Цена за единицу: {purchase.Price:C}");
                    Console.WriteLine($"Общая сумма: {purchase.TotalAmount:C}");
                    Console.WriteLine($"Статус: {purchase.Status}");
                }
                else
                {
                    Console.WriteLine($"Покупка с ID {id} не найдена.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void DisplayCustomerPurchases()
        {
            Console.Clear();
            Console.WriteLine("=== Просмотр покупок клиента ===\n");

            Console.Write("Введите ID клиента: ");
            if (int.TryParse(Console.ReadLine(), out int customerId))
            {
                var customer = _customerService.GetCustomerById(customerId);
                if (customer != null)
                {
                    Console.WriteLine($"\nПокупки клиента: {customer.FullName}\n");

                    var purchases = _purchaseService.GetPurchasesByCustomerId(customerId);
                    if (purchases.Count == 0)
                    {
                        Console.WriteLine("У этого клиента нет покупок.");
                    }
                    else
                    {
                        foreach (var purchase in purchases)
                        {
                            Console.WriteLine($"ID: {purchase.PurchaseId}, Продукт ID: {purchase.ProductId}, Дата: {purchase.PurchaseDate.ToShortDateString()}, Сумма: {purchase.TotalAmount:C}");
                        }
                        Console.WriteLine($"\nВсего покупок: {purchases.Count}");
                    }
                }
                else
                {
                    Console.WriteLine($"Клиент с ID {customerId} не найден.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void SearchPurchasesByDate()
        {
            Console.Clear();
            Console.WriteLine("=== Поиск покупок по дате ===\n");

            Console.Write("Введите дату (дд.мм.гггг): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime date))
            {
                var purchases = _purchaseService.SearchPurchasesByDate(date);
                if (purchases.Count == 0)
                {
                    Console.WriteLine($"Покупки за {date.ToShortDateString()} не найдены.");
                }
                else
                {
                    Console.WriteLine($"\nПокупки за {date.ToShortDateString()}:");
                    foreach (var purchase in purchases)
                    {
                        Console.WriteLine($"ID: {purchase.PurchaseId}, Клиент: {purchase.Customer?.FullName}, Продукт ID: {purchase.ProductId}, Сумма: {purchase.TotalAmount:C}");
                    }
                    Console.WriteLine($"\nВсего найдено: {purchases.Count}");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат даты.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void AddNewPurchase()
        {
            Console.Clear();
            Console.WriteLine("=== Добавление новой покупки ===\n");

            Console.Write("Введите ID клиента: ");
            if (!int.TryParse(Console.ReadLine(), out int customerId))
            {
                Console.WriteLine("Неверный формат ID клиента.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            var customer = _customerService.GetCustomerById(customerId);
            if (customer == null)
            {
                Console.WriteLine($"Клиент с ID {customerId} не найден.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            Console.Write("Введите ID продукта: ");
            if (!int.TryParse(Console.ReadLine(), out int productId))
            {
                Console.WriteLine("Неверный формат ID продукта.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            Console.Write("Введите количество: ");
            if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity <= 0)
            {
                Console.WriteLine("Неверное количество. Должно быть положительное число.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            Console.Write("Введите цену за единицу: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal price) || price <= 0)
            {
                Console.WriteLine("Неверная цена. Должна быть положительное число.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            Console.Write("Введите статус покупки: ");
            string status = Console.ReadLine();

            var purchase = new Purchase
            {
                CustomerId = customerId,
                ProductId = productId,
                Quantity = quantity,
                Price = price,
                Status = status,
                Customer = customer
            };

            var addedPurchase = _purchaseService.AddPurchase(purchase);
            Console.WriteLine($"\nПокупка успешно добавлена с ID: {addedPurchase.PurchaseId}");

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void EditPurchase()
        {
            Console.Clear();
            Console.WriteLine("=== Редактирование покупки ===\n");

            Console.Write("Введите ID покупки для редактирования: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var purchase = _purchaseService.GetPurchaseById(id);
                if (purchase != null)
                {
                    Console.WriteLine($"Редактирование покупки ID: {purchase.PurchaseId}\n");

                    Console.Write($"Количество [{purchase.Quantity}]: ");
                    if (int.TryParse(Console.ReadLine(), out int quantity) && quantity > 0)
                        purchase.Quantity = quantity;

                    Console.Write($"Цена за единицу [{purchase.Price:C}]: ");
                    if (decimal.TryParse(Console.ReadLine(), out decimal price) && price > 0)
                        purchase.Price = price;

                    Console.Write($"Статус [{purchase.Status}]: ");
                    string status = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(status))
                        purchase.Status = status;

                    bool success = _purchaseService.UpdatePurchase(purchase);
                    if (success)
                    {
                        Console.WriteLine("\nИнформация о покупке успешно обновлена.");
                    }
                    else
                    {
                        Console.WriteLine("\nПроизошла ошибка при обновлении информации о покупке.");
                    }
                }
                else
                {
                    Console.WriteLine($"Покупка с ID {id} не найдена.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void DeletePurchase()
        {
            Console.Clear();
            Console.WriteLine("=== Удаление покупки ===\n");

            Console.Write("Введите ID покупки для удаления: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var purchase = _purchaseService.GetPurchaseById(id);
                if (purchase != null)
                {
                    Console.WriteLine($"Вы уверены, что хотите удалить покупку ID: {purchase.PurchaseId}, Сумма: {purchase.TotalAmount:C}? (д/н)");
                    string confirmation = Console.ReadLine().ToLower();

                    if (confirmation == "д" || confirmation == "да" || confirmation == "y" || confirmation == "yes")
                    {
                        bool success = _purchaseService.DeletePurchase(id);
                        if (success)
                        {
                            Console.WriteLine("Покупка успешно удалена.");
                        }
                        else
                        {
                            Console.WriteLine("Произошла ошибка при удалении покупки.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Удаление отменено.");
                    }
                }
                else
                {
                    Console.WriteLine($"Покупка с ID {id} не найдена.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат ID.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void ShowPurchaseStatistics()
        {
            Console.Clear();
            Console.WriteLine("=== Статистика по покупкам ===\n");

            var statistics = _purchaseService.GetPurchaseStatistics();

            Console.WriteLine($"Общая сумма всех покупок: {statistics["TotalAmount"]:C}");
            Console.WriteLine($"Средняя сумма покупки: {statistics["AverageAmount"]:C}");
            Console.WriteLine($"Максимальная сумма покупки: {statistics["MaxAmount"]:C}");

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        #endregion

        #region Database Changes Methods

        private void DisplayAllChanges()
        {
            Console.Clear();
            Console.WriteLine("=== Журнал всех изменений ===\n");

            var changes = _changeService.GetAllChanges();
            if (changes.Count == 0)
            {
                Console.WriteLine("Изменения не найдены.");
            }
            else
            {
                foreach (var change in changes)
                {
                    Console.WriteLine($"ID: {change.ChangeId}, Таблица: {change.TableName}, Тип: {change.ChangeType}, Дата: {change.ChangeDate}, Описание: {change.Description}");
                }
                Console.WriteLine($"\nВсего изменений: {changes.Count}");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void DisplayChangesByTable()
        {
            Console.Clear();
            Console.WriteLine("=== Изменения по таблице ===\n");

            Console.WriteLine("Доступные таблицы:");
            Console.WriteLine("1. Customers");
            Console.WriteLine("2. Purchases");
            Console.Write("\nВыберите таблицу: ");

            string tableName = "";
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        tableName = "Customers";
                        break;
                    case 2:
                        tableName = "Purchases";
                        break;
                    default:
                        Console.WriteLine("Неверный выбор.");
                        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                        Console.ReadKey();
                        return;
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            var changes = _changeService.GetChangesByTable(tableName);
            if (changes.Count == 0)
            {
                Console.WriteLine($"Изменения в таблице {tableName} не найдены.");
            }
            else
            {
                Console.WriteLine($"\nИзменения в таблице {tableName}:");
                foreach (var change in changes)
                {
                    Console.WriteLine($"ID: {change.ChangeId}, Тип: {change.ChangeType}, Дата: {change.ChangeDate}, Описание: {change.Description}");
                }
                Console.WriteLine($"\nВсего изменений: {changes.Count}");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void DisplayChangesByType()
        {
            Console.Clear();
            Console.WriteLine("=== Изменения по типу ===\n");

            Console.WriteLine("Доступные типы изменений:");
            Console.WriteLine("1. Add (Добавление)");
            Console.WriteLine("2. Update (Обновление)");
            Console.WriteLine("3. Delete (Удаление)");
            Console.Write("\nВыберите тип: ");

            string changeType = "";
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        changeType = "Add";
                        break;
                    case 2:
                        changeType = "Update";
                        break;
                    case 3:
                        changeType = "Delete";
                        break;
                    default:
                        Console.WriteLine("Неверный выбор.");
                        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                        Console.ReadKey();
                        return;
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор.");
                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                return;
            }

            var changes = _changeService.GetChangesByType(changeType);
            if (changes.Count == 0)
            {
                Console.WriteLine($"Изменения типа {changeType} не найдены.");
            }
            else
            {
                Console.WriteLine($"\nИзменения типа {changeType}:");
                foreach (var change in changes)
                {
                    Console.WriteLine($"ID: {change.ChangeId}, Таблица: {change.TableName}, Дата: {change.ChangeDate}, Описание: {change.Description}");
                }
                Console.WriteLine($"\nВсего изменений: {changes.Count}");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void DisplayChangesByDate()
        {
            Console.Clear();
            Console.WriteLine("=== Изменения по дате ===\n");

            Console.Write("Введите дату (дд.мм.гггг): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime date))
            {
                var changes = _changeService.GetChangesByDate(date);
                if (changes.Count == 0)
                {
                    Console.WriteLine($"Изменения за {date.ToShortDateString()} не найдены.");
                }
                else
                {
                    Console.WriteLine($"\nИзменения за {date.ToShortDateString()}:");
                    foreach (var change in changes)
                    {
                        Console.WriteLine($"ID: {change.ChangeId}, Таблица: {change.TableName}, Тип: {change.ChangeType}, Описание: {change.Description}");
                    }
                    Console.WriteLine($"\nВсего изменений: {changes.Count}");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат даты.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        private void ClearOldChanges()
        {
            Console.Clear();
            Console.WriteLine("=== Очистка старых записей журнала ===\n");

            Console.Write("Введите дату, до которой нужно удалить записи (дд.мм.гггг): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime date))
            {
                Console.WriteLine($"Вы уверены, что хотите удалить все записи журнала до {date.ToShortDateString()}? (д/н)");
                string confirmation = Console.ReadLine().ToLower();

                if (confirmation == "д" || confirmation == "да" || confirmation == "y" || confirmation == "yes")
                {
                    int count = _changeService.ClearOldChanges(date);
                    Console.WriteLine($"Удалено {count} записей журнала.");
                }
                else
                {
                    Console.WriteLine("Очистка отменена.");
                }
            }
            else
            {
                Console.WriteLine("Неверный формат даты.");
            }

            Console.WriteLine("\nНажмите любую клавишу для продолжения...");
            Console.ReadKey();
        }

        #endregion
    }
}
