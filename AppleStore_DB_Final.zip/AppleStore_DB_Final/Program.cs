using System;
using AppleStore.UI;
using AppleStore.Services;
using AppleStore.Data;
using Microsoft.EntityFrameworkCore;

namespace AppleStore
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Создаем контекст базы данных
            var dbContext = new AppleStoreDbContext();
            
            // Создаем сервисы для работы с базой данных
            var databaseChangeService = new DatabaseChangeService(dbContext);
            var customerDbService = new CustomerDbService(dbContext, databaseChangeService);
            var purchaseDbService = new PurchaseDbService(dbContext, databaseChangeService);
            
            // Инициализируем базу данных тестовыми данными
            var databaseInitializer = new DatabaseInitializer(dbContext, databaseChangeService);
            databaseInitializer.Initialize();

            // Инициализация сервисов
            var categoryService = new CategoryService();
            var productService = new ProductService(categoryService);
            var productDetailsService = new ProductDetailsService(productService);
            var customerService = new CustomerService();
            var employeeService = new EmployeeService();
            var orderService = new OrderService(customerService, employeeService);
            var orderItemService = new OrderItemService(orderService, productService);

            // Создаем UI для работы с базой данных
            var databaseUI = new DatabaseUI(customerDbService, purchaseDbService, databaseChangeService);
            
            // Создаем консольный интерфейс
            var consoleUI = new ConsoleUI(
                categoryService,
                productService,
                productDetailsService,
                customerService,
                employeeService,
                orderService,
                orderItemService,
                databaseUI);

            // Запуск приложения
            Console.WriteLine("Запуск Apple Store...");
            consoleUI.Start();
        }
    }
}
